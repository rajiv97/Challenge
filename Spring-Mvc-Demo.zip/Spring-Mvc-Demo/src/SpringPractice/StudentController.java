package SpringPractice;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/student")
public class StudentController {
	int s;
	int n=70;
//	Student theStudent=new Student();
	@RequestMapping("/showForm")
	public String showForm(Model theModel) {
		
		Student theStudent=new Student();
		
		theModel.addAttribute("student",theStudent);
		
		return "student-form";
	}
	
	
	@RequestMapping("/processForm")
	public String processForm(@ModelAttribute("student") Student theStudent) {
		
		System.out.println("The Student "+ theStudent.getSource()+" "+theStudent.getDestination());
		
		String a1= (theStudent.getSource()).toUpperCase();
		String a2=(theStudent.getDestination()).toUpperCase();
		
		System.out.println("The Student "+ a1+" "+a2);
		
		if(((a1).equals("DELHI"))&&((a2).equals("JHANSI")))
		{
			theStudent.setYes("Govt. Buses");
			theStudent.setSeatno(n);
			 n=n-1;
		}
		else if(((a1).equals("DELHI"))&&((a2).equals("JAIPUR")))
		{
			theStudent.setYes("Govt. Buses");
			theStudent.setSeatno(n);
			 n=n-1;
		}
		else if(((a1).equals("DELHI"))&&((a2).equals("KOLKATA")))
		{
			theStudent.setYes("Govt. Buses");
			theStudent.setSeatno(n);
			 n=n-1;
		}
		else if(((a1).equals("DELHI"))&&((a2).equals("MUMBAI")))
		{
			theStudent.setYes("Govt. Buses");
			theStudent.setSeatno(n);
			 n=n-1;
		}
		else if(((a1).equals("DELHI"))&&((a2).equals("HYDERABAD")))
		{
			theStudent.setYes("Govt. Buses");
			theStudent.setSeatno(n);
			 n=n-1;
		}
		else {
			theStudent.setYes("No Buses");
		}
		
		
		return "student-conformation";
	}
	
	@RequestMapping("/processForm2")
	public String processForm2(@ModelAttribute("student") Student theStudent) {
		
		//System.out.println(theStudent.getName());
		//System.out.println("The Student 2"+ theStudent.getYes()+" "+theStudent.getDestination());
		return "student-book";
	}

	
	@RequestMapping("/processForm4")
	public String processForm4(@ModelAttribute("student") Student theStudent) {
		
		System.out.println(theStudent.getName());
		System.out.println(theStudent.getDestination());
		
		return "student-proceed";
	}
}
