package SpringPractice;

import java.util.LinkedHashMap;

public class Student {

	
	private String source;
	private String destination;
	private String seat;
	private String yes;
	private int seatno;
	
	private String name;
	private String male;
	private int age;
	
	
	public int getAge() {
		return age;
	}

	public void setAge(int age) {
		this.age = age;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	
	public String getMale() {
		return male;
	}

	public void setMale(String male) {
		this.male = male;
	}

	public String getYes() {
		return yes;
	}

	public void setYes(String yes) {
		this.yes = yes;
	}

	


	public int getSeatno() {
		return seatno;
	}

	public void setSeatno(int seatno) {
		this.seatno = seatno;
	}




	private LinkedHashMap<String, String> countryOption;
	
	
public Student() {
		
	countryOption= new LinkedHashMap<>();
	
	countryOption.put("ECO","Economy");
	countryOption.put("PRE","Premium");
	countryOption.put("BUSS","Bussiness");
	
	}
	
	public LinkedHashMap<String, String> getCountryOption() {
	return countryOption;
}

	public String getSeat() {
		return seat;
	}


	public void setSeat(String seat) {
		this.seat = seat;
	}


	


	public String getSource() {
		return source;
	}


	public void setSource(String source) {
		this.source = source;
	}


	public String getDestination() {
		return destination;
	}


	public void setDestination(String destination) {
		this.destination = destination;
	}
	
	
	
}
